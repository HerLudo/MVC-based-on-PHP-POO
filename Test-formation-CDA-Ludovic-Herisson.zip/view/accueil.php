<div class="mx-auto my-5 container d-flex flex-column align-items-center accueil">
    <div class="d-flex accueilDuo">
        <a href="?op=ajouter&data=patient"><button type="button" class="btn btn-outline-primary boutoncercle lignes1 mx-5">Ajouter un patient</button></a>
        <a href="?op=voir&data=patient&page=1"><button type="button" class="btn btn-outline-primary boutoncercle lignes1 mx-5">Voir la liste des patients</button></a>
    </div>

    <a href="?op=ajouter&data=rdvpatient"><button type="button" class="btn btn-outline-primary boutoncercle">Ajouter un patient et un RDV</button></a>

    <div class="d-flex accueilDuo">
        <a href="?op=ajouter&data=rdv"><button type="button" class="btn btn-outline-primary boutoncercle lignes1 mx-5">Ajouter un RDV</button></a>
        <a href="?op=voir&data=rdv"><button type="button" class="btn btn-outline-primary boutoncercle lignes1 mx-5">Voir la liste des RDV</button></a>
    </div>
</div>